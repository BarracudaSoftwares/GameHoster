# GameHoster

GameHoster is a Pterodactyl-based server management panel designed for easy server hosting. It allows users to create, manage, and host game servers with various customizable options.

## Features
- Easy-to-use interface
- Pterodactyl API integration
- User roles and permissions
- Ticketing system
- Forum integration
